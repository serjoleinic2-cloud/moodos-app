import { t } from '../i18n.js';

const LS_KEY = 'med_reminders_v2';

function getLocalNotifications() {
  try {
    return window.Capacitor?.Plugins?.LocalNotifications;
  } catch(e) { return null; }
}

export async function canPlaySound() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    await ctx.close();
    return true;
  } catch(e) {
    return false;
  }
}

export function getReminders() {
  try {
    return JSON.parse(localStorage.getItem(LS_KEY)) || [];
  } catch(e) { return []; }
}

export function saveReminders(reminders) {
  localStorage.setItem(LS_KEY, JSON.stringify(reminders));
}

async function cancelNotification(id) {
  try {
    const LocalNotifications = getLocalNotifications();
    if (!LocalNotifications) return;
    const base = (id % 100000) * 1000;
    const ids = Array.from({ length: 56 }, (_, i) => ({ id: base + i }));
    await LocalNotifications.cancel({ notifications: ids });
    console.log('[reminders] cancelled:', id);
  } catch(e) {
    console.warn('[reminders] cancel failed:', e);
  }
}

export function addReminder({ time, medName, days }) {
  const reminders = getReminders();
  const id = Date.now();
  reminders.push({ id, time, medName, days, active: true });
  saveReminders(reminders);
  scheduleNotification({ id, time, medName, days });
  return id;
}

export function updateReminder(id, { time, medName, days }) {
  const reminders = getReminders();
  const r = reminders.find(rem => rem.id === id);
  if (!r) return;
  r.time = time || r.time;
  r.medName = medName || r.medName;
  r.days = days || r.days;
  saveReminders(reminders);
  cancelNotification(id);
  if (r.active) scheduleNotification({ id, time: r.time, medName: r.medName, days: r.days });
}

export function deleteReminder(id) {
  const reminders = getReminders().filter(r => r.id !== id);
  saveReminders(reminders);
  cancelNotification(id);
}

export function toggleReminder(id) {
  const reminders = getReminders();
  const r = reminders.find(r => r.id === id);
  if (!r) return;
  r.active = !r.active;
  saveReminders(reminders);
  if (r.active) scheduleNotification(r);
  else cancelNotification(id);
}

async function scheduleNotification({ id, time, medName, days }) {
  const log = (msg, data) => console.log(`[reminders] ${msg}`, data !== undefined ? JSON.stringify(data) : '');
  const logErr = (msg, e) => console.error(`[reminders] ERROR ${msg}`, e?.message || e);

  try {
    log('scheduleNotification called', { id, time, medName, days });

    const LocalNotifications = getLocalNotifications();
    if (!LocalNotifications) {
      logErr('LocalNotifications plugin NOT FOUND', null);
      return;
    }
    log('plugin found OK');

    const perm = await LocalNotifications.checkPermissions();
    log('checkPermissions result', perm);

    if (perm.display !== 'granted') {
      const req = await LocalNotifications.requestPermissions();
      log('requestPermissions result', req);
      if (req.display !== 'granted') {
        logErr('permission denied', null);
        return;
      }
    }

    try {
      await LocalNotifications.createChannel({
        id: 'med_reminders',
        name: 'Напоминания о лекарствах',
        description: 'Уведомления о приёме лекарств',
        importance: 5,
        vibration: true,
        lights: true,
      });
      log('channel created OK');
    } catch(e) {
      log('channel already exists (OK)', e?.message);
    }

    try {
      if (window.Capacitor?.getPlatform() === 'android') {
        const { AlarmManager } = window.Capacitor?.Plugins || {};
        log('AlarmManager plugin available', !!AlarmManager);
        if (AlarmManager?.canScheduleExactAlarms) {
          const { value } = await AlarmManager.canScheduleExactAlarms();
          log('canScheduleExactAlarms', value);
          if (!value) {
            log('requesting exact alarm permission...');
            await AlarmManager.requestExactAlarmPermission();
          }
        } else {
          log('AlarmManager.canScheduleExactAlarms NOT available');
        }
      }
    } catch(e) {
      logErr('AlarmManager block', e);
    }

    const [hours, minutes] = time.split(':').map(Number);
    const dayMap = { пн:1, вт:2, ср:3, чт:4, пт:5, сб:6, вс:0 };
    
    const notifications = [];
    const now = new Date();
    log('current time', now.toISOString());
    
    let idCounter = 0;
    days.forEach((day) => {
      const jsDow = dayMap[day];
      for (let week = 0; week < 8; week++) {
        const target = new Date();
        target.setHours(hours, minutes, 0, 0);
        const currentDow = now.getDay();
        let daysUntil = (jsDow - currentDow + 7) % 7;
        if (daysUntil === 0 && target.getTime() <= now.getTime() + 30000) daysUntil = 7;
        daysUntil += week * 7;
        target.setDate(target.getDate() + daysUntil);
        notifications.push({
          id: (id % 100000) * 1000 + idCounter++,
          title: t('reminder_notif_title') || '💊 Time to take your medication',
          body: medName || (t('reminder_notif_body') || "Don't forget to take your medication"),
          schedule: { at: target, allowWhileIdle: true, exact: true },
          channelId: 'med_reminders',
        });
      }
    });

    log('notifications to schedule', notifications.length);
    log('first notification', notifications[0]);
    
    const result = await LocalNotifications.schedule({ notifications });
    log('schedule() result', result);

    const pending = await LocalNotifications.getPending();
    log('pending after schedule', pending?.notifications?.length);

  } catch(e) {
logErr('scheduleNotification outer catch', e);
  }
}

export async function checkRemindersOnBoot() {
  try {
    const LocalNotifications = getLocalNotifications();
    if (!LocalNotifications) return;

    const reminders = getReminders().filter(r => r.active);
    if (!reminders.length) return;

    const perm = await LocalNotifications.checkPermissions();
    if (perm.display !== 'granted') return;

    const pending = await LocalNotifications.getPending();
    const pendingIds = new Set(pending.notifications.map(n => n.id));

    for (const r of reminders) {
      const base = (r.id % 100000) * 1000;
      const remaining = Array.from({ length: 56 }, (_, i) => base + i)
        .filter(id => pendingIds.has(id)).length;
      if (remaining < 4) {
        await cancelNotification(r.id);
        await scheduleNotification(r);
      }
    }
    console.log('[reminders] boot check done');
  } catch(e) {
    console.warn('[reminders] boot check failed:', e);
  }
}