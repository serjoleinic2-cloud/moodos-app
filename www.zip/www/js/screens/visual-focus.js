// ===============================
// Neyra Visual Focus (EMDR-style)
// Зрительный якорь — 2 минуты
// ===============================
import { getMood } from "../state.js";
import { addSessionEntry, getLastRealMood } from "../services/memory.js";
import SystemCore from "../system-core.js";
import { t } from "../i18n.js";

let animationId = null;
let running = false;
let sessionStartTime = null;
let moodBeforeSession = null;
let stateBeforeSession = null;
let countdownInterval = null;

const DURATION = 120;

let speedMs = 2200;
let result = null;
let finalDuration = 0;

export function onEnter(container) {
  console.log('[DEBUG] visual-focus onEnter called');
  render(container);
  bindEvents();
}

function render(container) {
  container.innerHTML = `
    <div style="text-align:center; margin-top:20px;">

      <h2 style="margin-bottom:6px;">${t("vf_title")}</h2>
      <div style="font-size:14px; color:#888; margin-bottom:20px;">
        ${t("vf_subtitle")}
      </div>

      <!-- СКОРОСТЬ -->
      <div id="vfSpeedRow" style="display:flex; justify-content:center; gap:10px; margin-bottom:16px;">
        <button class="vfSpeed" data-speed="slow" style="
          padding:8px 18px; border:none; border-radius:12px; cursor:pointer;
          background:#e0e5ec; box-shadow: 4px 4px 8px #b8bec7, -4px -4px 8px #ffffff;
          color:#555; font-size:14px;">${t("vf_slow")}</button>
        <button class="vfSpeed" data-speed="normal" style="
          padding:8px 18px; border:none; border-radius:12px; cursor:pointer;
          background:#e0e5ec; box-shadow: 4px 4px 8px #b8bec7, -4px -4px 8px #ffffff;
          color:#555; font-size:14px; font-weight:600;">${t("vf_normal")}</button>
        <button class="vfSpeed" data-speed="fast" style="
          padding:8px 18px; border:none; border-radius:12px; cursor:pointer;
          background:#e0e5ec; box-shadow: 4px 4px 8px #b8bec7, -4px -4px 8px #ffffff;
          color:#555; font-size:14px;">${t("vf_fast")}</button>
      </div>

      <!-- ПОЛЕ -->
      <div id="vfField" style="
        position:relative; width:100%; height:160px;
        border-radius:20px; background:#e0e5ec;
        box-shadow: inset 6px 6px 12px #b8bec7, inset -6px -6px 12px #ffffff;
        overflow:hidden; margin-bottom:16px;">
        <div id="vfDot" style="
          position:absolute; top:50%; transform:translateY(-50%);
          width:36px; height:36px; border-radius:50%;
          background: radial-gradient(circle at 35% 35%, #a78bfa, #6d28d9);
          box-shadow: 0 0 18px #a78bfa;
          left:10px; transition: none;
        "></div>
      </div>

      <!-- ТАЙМЕР -->
      <div id="vfTimerWrap" style="margin-bottom:16px;">
        <div id="vfTimer" style="font-size:42px; font-weight:bold; color:#6d28d9;">2:00</div>
        <div id="vfStatus" style="font-size:14px; color:#888; margin-top:4px;">${t("vf_ready")}</div>
      </div>

      <!-- КНОПКА -->
      <div style="display:flex; justify-content:center; margin-bottom:20px;">
        <button id="vfMainBtn" class="mainBtn" style="border:none;border-radius:50%;width:72px;height:72px;cursor:pointer;display:flex;align-items:center;justify-content:center;">
          <img id="vfPlayIcon" src="/icons/player/play.svg" style="width:28px;height:28px;">
        </button>
      </div>

      <!-- ФИДБЕК -->
      <div id="vfFeedback" style="display:none; flex-direction:column; gap:14px; align-items:center; margin-top:10px;">
        <div style="font-size:16px; color:#666; margin-bottom:6px;">${t("vf_how_feel")}</div>
        <div id="vfHelped" style="
          width:75%; padding:16px; border-radius:18px; cursor:pointer;
          background:#e0e5ec; box-shadow: 6px 6px 12px #b8bec7, -6px -6px 12px #ffffff;
          color:#4a7c59; font-size:18px; text-align:center;">👍 ${t("hist_helped")}</div>
        <div id="vfNotHelped" style="
          width:75%; padding:16px; border-radius:18px; cursor:pointer;
          background:#e0e5ec; box-shadow: 6px 6px 12px #b8bec7, -6px -6px 12px #ffffff;
          color:#888; font-size:18px; text-align:center;">👎 ${t("hist_not_helped")}</div>
      </div>

    </div>
  `;
}

function bindEvents() {
  console.log('[DEBUG] visual-focus bindEvents called');

  document.querySelectorAll(".vfSpeed").forEach(btn => {
    btn.replaceWith(btn.cloneNode(true));
  });
  
  document.querySelectorAll(".vfSpeed").forEach(btn => {
    btn.onclick = () => {
      document.querySelectorAll(".vfSpeed").forEach(b => b.style.fontWeight = "normal");
      btn.style.fontWeight = "600";
      const s = btn.dataset.speed;
      if (s === "slow")   speedMs = 3500;
      if (s === "normal") speedMs = 2200;
      if (s === "fast")   speedMs = 1200;
    };
  });

  const mainBtn = document.getElementById("vfMainBtn");
  if (mainBtn) {
    const newMainBtn = mainBtn.cloneNode(true);
    mainBtn.replaceWith(newMainBtn);
    newMainBtn.onclick = async () => {
      console.log('[DEBUG] mainBtn clicked, running:', running);
      if (!running) {
        await startSession();
      } else {
        stopSession();
        showFeedback();
      }
    };
  }

  const vfHelped = document.getElementById("vfHelped");
  if (vfHelped) {
    const newHelped = vfHelped.cloneNode(true);
    vfHelped.replaceWith(newHelped);
    newHelped.onclick = () => {
      if (newHelped.dataset.locked) return;
      newHelped.dataset.locked = 'true';
      saveSessionWithResult("positive");
    };
  }

  const vfNotHelped = document.getElementById("vfNotHelped");
  if (vfNotHelped) {
    const newNotHelped = vfNotHelped.cloneNode(true);
    vfNotHelped.replaceWith(newNotHelped);
    newNotHelped.onclick = () => {
      if (newNotHelped.dataset.locked) return;
      newNotHelped.dataset.locked = 'true';
      saveSessionWithResult("negative");
    };
  }
}

function getElements() {
  return {
    mainBtn: document.getElementById("vfMainBtn"),
    feedback: document.getElementById("vfFeedback"),
    dot: document.getElementById("vfDot"),
    field: document.getElementById("vfField"),
    status: document.getElementById("vfStatus")
  };
}

function showPlayer() {
  document.getElementById("vfSpeedRow").style.display = "flex";
  document.getElementById("vfTimerWrap").style.display = "block";
  const { mainBtn, feedback } = getElements();
  if (mainBtn) mainBtn.style.display = "flex";
  if (feedback) feedback.style.display = "none";
}

function showFeedback() {
  document.getElementById("vfSpeedRow").style.display = "none";
  document.getElementById("vfTimerWrap").style.display = "none";
  const { mainBtn, feedback } = getElements();
  if (mainBtn) mainBtn.style.display = "none";
  if (feedback) feedback.style.display = "flex";
}

function updateTimerDisplay(sec) {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  const timerEl = document.getElementById("vfTimer");
  if (timerEl) timerEl.textContent = `${m}:${String(s).padStart(2, "0")}`;
}

async function startSession() {
  running = true;
  sessionStartTime = Date.now();
  moodBeforeSession = getLastRealMood() ?? getMood();
  const analysisResult = await SystemCore.analyzeMoodOnly(moodBeforeSession);
  stateBeforeSession = analysisResult ? analysisResult.state : null;
  
  const { mainBtn, status } = getElements();
  const icon1 = document.getElementById("vfPlayIcon");
  if (icon1) icon1.src = "/icons/player/pause.svg";
  if (status) status.textContent = t("vf_watching");

  let remaining = DURATION;
  updateTimerDisplay(remaining);

  countdownInterval = setInterval(() => {
    remaining--;
    updateTimerDisplay(remaining);
    if (remaining <= 0) {
      stopSession();
      showFeedback();
    }
  }, 1000);

  animateDot();
}

function stopSession() {
  running = false;
  if (animationId) cancelAnimationFrame(animationId);
  if (countdownInterval) clearInterval(countdownInterval);
  const { status } = getElements();
  if (status) status.textContent = t("vf_stopped");
  
  if (sessionStartTime) {
    finalDuration = Math.floor((Date.now() - sessionStartTime) / 1000);
  }
}

function animateDot() {
  const { dot, field } = getElements();
  if (!dot || !field) return;
  
  if (!running) return;
  const fieldW = field.offsetWidth;
  const dotW = 36;
  const maxLeft = fieldW - dotW - 10;
  let goRight = true;
  let startX = 10;
  let startTime = null;

  function step(ts) {
    if (!running) return;
    if (!startTime) startTime = ts;
    const elapsed = ts - startTime;
    const progress = Math.min(elapsed / speedMs, 1);
    const eased = 0.5 - Math.cos(progress * Math.PI) / 2;
    const fromX = goRight ? startX : maxLeft;
    const toX = goRight ? maxLeft : 10;
    const x = fromX + (toX - fromX) * eased;
    dot.style.left = x + "px";

    if (progress >= 1) {
      goRight = !goRight;
      startX = x;
      startTime = null;
    }
    animationId = requestAnimationFrame(step);
  }
  animationId = requestAnimationFrame(step);
}

async function saveSession() {
  const moodAfter = getMood();
  const analysisResult = await SystemCore.analyzeMoodOnly(moodAfter);
  const stateAfter = analysisResult ? analysisResult.state : null;
  
  addSessionEntry({
    type: "visual-focus",
    moodBefore: moodBeforeSession,
    stateBefore: stateBeforeSession,
    moodAfter,
    stateAfter,
    result,
    duration: finalDuration,
    timestamp: Date.now()
  });
  
  sessionStartTime = null;
  moodBeforeSession = null;
  finalDuration = 0;
  updateTimerDisplay(DURATION);
  
  const { mainBtn, status } = getElements();
  const icon2 = document.getElementById("vfPlayIcon");
  if (icon2) icon2.src = "/icons/player/play.svg";
  if (status) status.textContent = t("vf_ready");
  showPlayer();
}

function saveSessionWithResult(res) {
  result = res;
  saveSession();
}
